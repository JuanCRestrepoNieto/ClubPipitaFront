import React from "react";
import css from './EstilosConsulta.module.css';

function FRMConsultarJugador(props){
    return(
        <></> 
    );
}

export{FRMConsultarJugador}